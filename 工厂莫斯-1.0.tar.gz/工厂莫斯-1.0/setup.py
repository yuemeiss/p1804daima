#!/usr/bin/env python
# coding=utf-8
from distutils.core import setup
setup(name="工厂莫斯",version="1.0",description=' 作业 module',author='斯蒂芬.约梅', py_modules=['gongchang.g工厂模式'])
