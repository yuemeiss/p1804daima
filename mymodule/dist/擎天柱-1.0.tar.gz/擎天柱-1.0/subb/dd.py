def gg():
    print('+++++++++++')

