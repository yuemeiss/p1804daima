def xx():
    print('**************')
