def ii():
    print('**************')
