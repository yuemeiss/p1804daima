#!/usr/bin/env python
# coding=utf-8
from distutils.core import setup
setup(name="擎天柱",version="1.0",description='测试 module',author='晴天住', py_modules=['suba.aa','suba.bb','subb.cc','subb.dd'])
